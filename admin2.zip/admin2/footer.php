<div class="footer">
	   <p>&copy; 2022 Design Dashboard. All Rights Reserved | Design by <a href="" target="_blank">Harsh shah</a></p>		
	</div>