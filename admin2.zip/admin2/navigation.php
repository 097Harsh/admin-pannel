<aside class="sidebar-left">
      <nav class="navbar navbar-inverse">
          <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target=".collapse" aria-expanded="false">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            </button>
            <h1><a class="navbar-brand" href="dashboard.php"><span>Admin</span></a></h1>
          </div>
          <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="sidebar-menu">
              <li class="header"></li>
              
              
              <li class="treeview">
                <a href="dashboard.php">
                <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
              </li>
			        <li class="treeview">
                <a href="forms.php">
                <i class="fa fa-edit"></i> <span>Forms</span>
                </a>
              </li>
              <li class="treeview">
                <a href="tables.php">
                <i class="fa fa-list"></i> <span>view all Inquiry</span>
                </a>
              </li>
              <li class="treeview">
              <a href="index.php">
                <i class="fa fa-sign-in"></i> <span>logout</span>
                </a>
              </li>
             </ul>
          </div>
          <!-- /.navbar-collapse -->
      </nav>
    </aside>
	</div>
	